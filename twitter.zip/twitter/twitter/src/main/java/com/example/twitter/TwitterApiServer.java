package com.example.twitter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Objects;

@SpringBootApplication
@RestController
public class TwitterApiServer {

    private static final String BASE_URL = "https://api.twitter.com";
    private static final String SEARCH_USERS_ENDPOINT = "/2/users/by";
    private static final String TWEETS_ENDPOINT = "/2/users/%s/tweets";

    private final String apiKey = "YOUR_API_KEY";
    private final String apiSecret = "YOUR_API_SECRET";
    private final String encodedCredentials = Base64.getEncoder().encodeToString((apiKey + ":" + apiSecret).getBytes());

    public static void main(String[] args) {
        SpringApplication.run(TwitterApiServer.class, args);
    }

    @GetMapping("/search-users")
    public ResponseEntity<String> searchUsers(@RequestParam("query") String query) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(getBearerToken());
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        String url = BASE_URL + SEARCH_USERS_ENDPOINT + "?usernames=" + query;
        return restTemplate.postForEntity(url, entity, String.class);
    }

    @GetMapping("/tweets")
    public ResponseEntity<String> getTweets(@RequestParam("username") String username) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(getBearerToken());
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        String url = BASE_URL + String.format(TWEETS_ENDPOINT, username);
        return restTemplate.exchange(url, org.springframework.http.HttpMethod.GET, entity, String.class);
    }

    private String getBearerToken() {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.set("Authorization", "Basic " + encodedCredentials);
        HttpEntity<String> entity = new HttpEntity<>("grant_type=client_credentials", headers);
        ResponseEntity<String> response = restTemplate.postForEntity(BASE_URL + "/oauth2/token", entity, String.class);
        return Objects.requireNonNull(response.getBody()).split(",")[0].split(":")[1].replace("\"", "");
    }
}
